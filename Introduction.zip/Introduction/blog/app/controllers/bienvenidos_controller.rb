class BienvenidosController < ApplicationController
  def index
  end
end
